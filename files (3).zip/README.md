# Data Cleaning and EDA Pipeline | Python, Pandas

A reusable Pandas workflow: raw CSV in, clean CSV + cleaning report + descriptive statistics + correlation analysis + charts out. The dataset-specific rules sit in one `CONFIG` dict in `pipeline.py`; the functions are generic.

**Dataset:** used-car listings, 12 columns (listing_id, brand, model, year, price_lakh, mileage_km, fuel_type, transmission, engine_cc, owner_count, city, listing_date), 5,150 raw rows. It is synthetic and built to mimic a messy public listings file; to use a real public CSV, edit `CONFIG` (column names, maps, ranges) and run the same command.

## Run
    pip install pandas matplotlib
    python make_raw_data.py                 # optional: regenerates the raw file
    python run_pipeline.py --input raw/car_listings_raw.csv --output outputs

## What the pipeline does
| Step | Result on this data |
|---|---|
| Remove duplicates (exact rows, then repeated IDs) | 150 removed |
| Standardise text (trim, case, variants like "Pet.", "Dsl", "EV", "AT", "MT") | ~600 brand, ~890 fuel, ~510 transmission, ~460 city values fixed |
| Parse mixed date formats (4 formats) | 0 unparsed |
| Convert numerics ("NA" to missing); out-of-range values set to missing | 6 impossible years, 5 negative prices |
| Missing values in 5 columns | price (dropped, it is the target), mileage and owner count (median by year), engine_cc (median by brand and model), fuel type (mode by brand); 0 missing after |
| Feature | `age` = listing year - model year |
| Output | 4,797 clean rows |

## EDA outputs (`outputs/`)
`clean_data.csv` · `cleaning_report.json` · `descriptive_stats.csv` (with skew) · `correlation_pearson.csv` · `correlation_spearman.csv` · `top_relationships.csv` · `charts/` (heatmap, distributions, 3 scatter plots)

## 3 key relationships found
1. **Price falls with vehicle age** (Spearman -0.73, Pearson -0.54). The gap shows the decay is non-linear, so rank correlation fits better than Pearson.
2. **Price falls with mileage** (Spearman -0.68). Mileage and age are themselves strongly linked (Pearson +0.88), so they overlap: a regression should not treat them as independent.
3. **Engine size has only a weak positive link to price** (+0.17 Pearson, +0.22 Spearman) and is almost uncorrelated with age or mileage, so it adds little on its own to explain price.
