"""Usage: python run_pipeline.py --input raw/car_listings_raw.csv --output outputs"""
import argparse, json, os, pandas as pd
from pipeline import clean, explore, CONFIG
ap = argparse.ArgumentParser(); ap.add_argument("--input", default="raw/car_listings_raw.csv"); ap.add_argument("--output", default="outputs"); a = ap.parse_args()
os.makedirs(a.output, exist_ok=True)
df, rep = clean(pd.read_csv(a.input, dtype=str)); df.to_csv(f"{a.output}/clean_data.csv", index=False)
json.dump(rep, open(f"{a.output}/cleaning_report.json", "w"), indent=2)
desc, pairs = explore(df, CONFIG, a.output)
print(json.dumps(rep, indent=1)); print(desc); print(pairs)
g = df.groupby("transmission")[CONFIG["target"]].median().round(2); print(g)
