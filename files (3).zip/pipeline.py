"""Reusable cleaning + EDA toolkit. Dataset-specific settings live in a CONFIG dict, the functions stay generic."""
import json, numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt

CONFIG = {
    "id_col": "listing_id",
    "text_cols": ["brand", "fuel_type", "transmission", "city"],
    "text_maps": {  # canonical value <- variants (compared after strip + lower-case)
        "brand": {"BMW": ["bmw"]},
        "fuel_type": {"Petrol": ["petrol", "pet."], "Diesel": ["diesel", "dsl"], "CNG": ["cng"], "Electric": ["electric", "ev"]},
        "transmission": {"Automatic": ["automatic", "at", "auto"], "Manual": ["manual", "mt"]}},
    "date_cols": {"listing_date": ["%Y-%m-%d", "%d/%m/%Y", "%b %d, %Y", "%d-%m-%y"]},
    "numeric_cols": ["year", "price_lakh", "mileage_km", "engine_cc", "owner_count"],
    "valid_ranges": {"year": (1990, 2026), "price_lakh": (0.1, 500), "mileage_km": (0, 1_000_000), "owner_count": (1, 10)},
    "missing": {  # column -> (strategy, group-by columns)
        "price_lakh": ("drop", []),                  # target variable: never impute
        "mileage_km": ("median", ["year"]),
        "engine_cc": ("median", ["brand", "model"]),
        "owner_count": ("median", ["year"]),
        "fuel_type": ("mode", ["brand"])},
    "eda_numeric": ["price_lakh", "age", "mileage_km", "engine_cc", "owner_count"],
    "target": "price_lakh",
}

def standardise_text(df, cfg, report):
    for c in cfg["text_cols"]:
        s = df[c].astype("string").str.strip().str.replace(r"\s+", " ", regex=True)
        key = s.str.lower(); lookup = {v: k for k, vs in cfg["text_maps"].get(c, {}).items() for v in vs}
        s = key.map(lambda x: lookup.get(x, x.title() if isinstance(x, str) else x)) if c in cfg["text_maps"] else s.str.title()
        if c == "fuel_type": s = s.where(s.isin(cfg["text_maps"][c]) | s.isna(), pd.NA)
        report[f"text_variants_fixed_{c}"] = int((df[c].astype("string") != s).fillna(False).sum()); df[c] = s
    return df

def parse_dates(df, cfg, report):
    for c, fmts in cfg["date_cols"].items():
        raw = df[c].astype("string").str.strip(); out = pd.Series(pd.NaT, index=df.index)
        for f in fmts: out = out.fillna(pd.to_datetime(raw, format=f, errors="coerce"))
        report[f"dates_unparsed_{c}"] = int(out.isna().sum()); df[c] = out
    return df

def clean(df_raw, cfg=CONFIG):
    r = {"rows_raw": len(df_raw)}; df = df_raw.copy()
    n = len(df); df = df.drop_duplicates(); r["exact_duplicates_removed"] = n - len(df)
    n = len(df); df = df.drop_duplicates(cfg["id_col"], keep="first"); r["duplicate_ids_removed"] = n - len(df)
    df = standardise_text(df, cfg, r); df = parse_dates(df, cfg, r)
    for c in cfg["numeric_cols"]: df[c] = pd.to_numeric(df[c], errors="coerce")        # "NA" etc -> NaN
    for c, (lo, hi) in cfg["valid_ranges"].items():
        bad = df[c].notna() & ~df[c].between(lo, hi); r[f"invalid_set_missing_{c}"] = int(bad.sum()); df.loc[bad, c] = np.nan
    r["missing_before"] = {c: int(df[c].isna().sum()) for c in cfg["missing"]}
    for c, (how, by) in cfg["missing"].items():
        if how == "drop": df = df.dropna(subset=[c]); continue
        f = (lambda x: x.median()) if how == "median" else (lambda x: x.mode().iat[0] if x.notna().any() else np.nan)
        df[c] = df[c].fillna(df.groupby(by)[c].transform(f)) if by else df[c].fillna(f(df[c]))
        df[c] = df[c].fillna(f(df[c]))                                                   # fallback to global value
    r["missing_after"] = {c: int(df[c].isna().sum()) for c in cfg["missing"]}
    df["age"] = df["listing_date"].dt.year - df["year"]; df = df[df["age"] >= 0]
    r["rows_clean"] = len(df); return df.reset_index(drop=True), r

def explore(df, cfg=CONFIG, out="outputs"):
    import os; os.makedirs(f"{out}/charts", exist_ok=True); cols = cfg["eda_numeric"]
    desc = df[cols].describe().T.round(2); desc["skew"] = df[cols].skew().round(2); desc.to_csv(f"{out}/descriptive_stats.csv")
    pear = df[cols].corr().round(3); spear = df[cols].corr(method="spearman").round(3)
    pear.to_csv(f"{out}/correlation_pearson.csv"); spear.to_csv(f"{out}/correlation_spearman.csv")
    pairs = (pear.where(np.triu(np.ones(pear.shape), 1).astype(bool)).stack().dropna().rename("pearson_r").reset_index()
             .rename(columns={"level_0": "var_1", "level_1": "var_2"}))
    pairs["spearman_rho"] = [spear.loc[a, b] for a, b in zip(pairs.var_1, pairs.var_2)]
    pairs = pairs.reindex(pairs.pearson_r.abs().sort_values(ascending=False).index); pairs.to_csv(f"{out}/top_relationships.csv", index=False)
    fig, ax = plt.subplots(figsize=(6, 5)); im = ax.imshow(pear, cmap="RdBu_r", vmin=-1, vmax=1)
    ax.set_xticks(range(len(cols)), cols, rotation=40, ha="right"); ax.set_yticks(range(len(cols)), cols)
    for i in range(len(cols)):
        for j in range(len(cols)): ax.text(j, i, f"{pear.iat[i,j]:.2f}", ha="center", va="center", fontsize=8)
    fig.colorbar(im); ax.set_title("Correlation matrix (Pearson)"); fig.tight_layout(); fig.savefig(f"{out}/charts/correlation_heatmap.png", dpi=150); plt.close()
    for x in ["age", "engine_cc", "mileage_km"]:
        fig, ax = plt.subplots(figsize=(5.5, 4)); ax.scatter(df[x], df[cfg["target"]], s=4, alpha=.3); ax.set_xlabel(x); ax.set_ylabel(cfg["target"])
        ax.set_title(f"{cfg['target']} vs {x}"); fig.tight_layout(); fig.savefig(f"{out}/charts/scatter_{x}.png", dpi=150); plt.close()
    fig, axs = plt.subplots(1, len(cols), figsize=(15, 3)); 
    for a, c in zip(axs, cols): a.hist(df[c], bins=30, color="#5b8def"); a.set_title(c, fontsize=9)
    fig.tight_layout(); fig.savefig(f"{out}/charts/distributions.png", dpi=150); plt.close()
    return desc, pairs
